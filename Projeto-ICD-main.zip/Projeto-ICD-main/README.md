# Projeto-ICD
Projeto destinado a disciplina de Introdução a Ciência de Dados, código em Python e utilizando o Jupyter Notebook.

Títuo do Projeto: Vendas de Games em diferentes plataformas e gêneros

Professor: Yuri de Almeida Malheiros Barbosa

Grupo:  Silvan Souza da Silva Lopes;
        Maria Carlyni Pereira de Oliveira;
        Mateus Fonsêca Henriques.
        
Base de Dados: https://www.kaggle.com/gregorut/videogamesales

Projeto #2 - Exploração Inicial
Yuri Malheiros

28 de out. Editado às 1 de nov.
Data de entrega: 9 de nov.
Como segundo passo do projeto vocês tem as seguintes tarefas:

1. Criar um repositório no Github para o projeto - OK
2. Criar um README.md com o título do projeto, nomes dos integrantes e dataset(s) utilizado(s) - OK
3. Colocar o(s) dataset(s) utilizados no repositório - OK
4. Criar um Jupyter Notebook para iniciar a exploração dos datasets - OK
5. No notebook, calcular medidas de centralidade e dispersão dos valores disponíveis nos datasets - OK
6. No notebook, criar boxplots para os dados disponíveis nos datasets - OK
